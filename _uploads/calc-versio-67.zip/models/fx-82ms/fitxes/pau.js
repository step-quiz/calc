/* ═══════════════════════════════════════════════════════════════════
   models/fx-82ms/fitxes/pau.js — «Funcions útils per a la PAU» (fx-82MS)
   ───────────────────────────────────────────────────────────────────
   NOMÉS DADES. Els mateixos temes i ids que a la CW, menys els que
   necessiten f(x) o Verificar (definir-fx, barrow, verificar).
   ═══════════════════════════════════════════════════════════════════ */
(function (M) {
'use strict';

const {calc, marca} = M.guions;
const {D} = M.comu;

M.fitxes.push(

{
  id: 'ans',
  inici: calc(D),
  passos: [
    {tecles: ['sin', '3', '5'], pantalla: calc(D, 'sin 35'),
      text: '[calc]Primer, $\\sin 35^\\circ$: [[sin]] i el 35.[/calc]'},
    {tecles: ['igual'], pantalla: marca(calc(D, 'sin 35', '0.573576436'), 'resultat'),
      text: '[calc]Prem [[igual]]. La calculadora desa el resultat a [[ans]] sense arrodonir-lo: la pantalla només en mostra deu xifres.[/calc]'},
    {tecles: ['8', 'entre', 'ans'], pantalla: calc(D, '8÷Ans'),
      text: '[mat]Ara vols $8\\div\\sin 35^\\circ$.[/mat] [calc]No escriguis el decimal: escriu 8, [[entre]] i la tecla [[ans]].[/calc]'},
    {tecles: ['igual'], pantalla: marca(calc(D, '8÷Ans', '13.94757436'), 'resultat'),
      text: '[calc]Prem [[igual]]: 13.94757436. Cap decimal copiat, cap error d\'arrodoniment.[/calc]'},
    {tecles: ['per', '2', 'igual'], pantalla: marca(calc(D, 'Ans×2', '27.89514873'), 'resultat'),
      text: '[calc]Si ara en vols el doble, no cal [[ans]]: després d\'un resultat, una operació com [[per]] ja comença amb Ans.[/calc]'},
    {error: true, tecles: ['ac', '8', 'entre', '0', 'punt', '5', '7', 'igual'], pantalla: marca(calc(D, '8÷0.57', '14.03508772'), 'resultat'),
      text: '[calc]!!Error típic!!: esborra amb [[ac]] i copia només 0.57 en lloc de $\\sin 35^\\circ$. Surt 14.03508772 i no 13.94757436: ja falla el primer decimal.[/calc]'},
  ],
  relacionades: ['logaritmes', 'exacte-decimal'],
},
{
  id: 'logaritmes',
  tancament: '[mat]Recorda: $\\log_3 7=\\log 7\\div\\log 3\\approx 1{,}7712$; al denominador hi va $\\log 3$, no el 3.[/mat]',
  enunciat: 'Resol l\'equació $3^x=7$: calcula $x=\\log_3 7$ i comprova el resultat. La fx-82MS no té logaritme en base qualsevol: es fa amb $\\log_3 7=\\dfrac{\\log 7}{\\log 3}$.',
  inici: calc(D),
  passos: [
    {tecles: ['log', '7', 'entre', 'log', '3'], pantalla: calc(D, 'log 7÷log 3'),
      text: '[calc]Escriu $\\log 7\\div\\log 3$: [[log]], el 7, [[entre]], [[log]] i el 3. Cada log s\'aplica al nombre que té darrere.[/calc]'},
    {tecles: ['igual'], pantalla: marca(calc(D, 'log 7÷log 3', '1.771243749'), 'resultat'),
      text: '[calc]Prem [[igual]]: $x=\\log_3 7\\approx 1{,}7712$. Amb [[ln]] en lloc de [[log]] surt el mateix.[/calc]'},
    {tecles: ['3', 'pot', 'ans'], pantalla: calc(D, '3^Ans'),
      text: '[mat]Comprova-ho: $3^x$ ha de valer 7.[/mat] [calc]Escriu 3, [[pot]] i [[ans]] (el resultat d\'abans, sense copiar-lo).[/calc]'},
    {tecles: ['igual'], pantalla: marca(calc(D, '3^Ans', '7'), 'resultat'),
      text: '[calc]Prem [[igual]]: surt 7. ✓[/calc]'},
    {error: true, tecles: ['ac', 'log', '7', 'entre', '3', 'igual'], pantalla: marca(calc(D, 'log 7÷3', '0.281699347'), 'resultat'),
      text: '[calc]!!Error típic!!: esborra amb [[ac]] i escriu $\\log 7\\div 3$: és $(\\log 7)\\div 3$, no $\\log_3 7$: surt 0.281699347. Al denominador hi va $\\log 3$.[/calc]'},
  ],
  relacionades: ['ans'],
},
{
  id: 'combinatoria',
  inici: calc(D),
  passos: [
    {tecles: ['6', 'ncr', '4'], pantalla: calc(D, '6C4'),
      text: '[calc]A la fx-82MS, el nombre combinatori té una tecla pròpia: escriu el 6, prem [[ncr]] i escriu el 4. «6C4» és $\\binom{6}{4}$.[/calc]'},
    {tecles: ['per', '0', 'punt', '5', 'pot', '6'], pantalla: calc(D, '6C4×0.5^6'),
      text: '[calc]Continua amb [[per]] i $0{,}5^6$: 0.5, [[pot]] i el 6.[/calc]'},
    {tecles: ['igual'], pantalla: marca(calc(D, '6C4×0.5^6', '0.234375'), 'resultat'),
      text: '[calc]Prem [[igual]]: 0.234375, perquè $\\binom{6}{4}=15$.[/calc]'},
    {tecles: ['abc'], pantalla: marca(calc(D, '6C4×0.5^6', '15┘64'), 'resultat'),
      text: '[calc]Amb [[abc]], en fracció: $P(X=4)=\\frac{15}{64}$. Amb [[shift]] [[ncr]] hi ha nPr (permutacions) i, amb [[shift]] [[inv]], el factorial.[/calc]'},
  ],
  relacionades: ['pau-pro-24i-q4', 'pot-fraccio'],
},

);

})(Models.obre());
