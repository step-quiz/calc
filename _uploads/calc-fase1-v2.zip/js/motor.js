/* ═══════════════════════════════════════════════════════════════════
   motor.js — La pàgina d'una fitxa i el seu reproductor pas a pas
   ───────────────────────────────────────────────────────────────────
   Segueix el model dels procediments de PAU (step-quiz/pau,
   procediments/motor.js): una fitxa és una llista d'estats; el motor
   en dibuixa un i anima el pas al següent.

   Dues columnes (David, 31/10/2026):
     · a l'esquerra, tot el que es llegeix: l'enunciat, el reproductor i
       la llista de passos. El pas actual es desplega i mostra la seva
       frase; a sota, les altres fitxes del bloc, plegades;
     · a la dreta, només la calculadora (pantalla i teclat sencer).
   Animació d'un pas: les tecles del pas s'emmarquen al teclat (amb el
   número d'ordre si n'hi ha més d'una), el cursor les prem una a una i,
   al final, la pantalla canvia.

   Pas 0 (idx = -1): la pantalla de partida (fitxa.inici).
   Depèn de KaTeX, Tecles, Pantalla, G i Dades. Exporta «Motor».
   ═══════════════════════════════════════════════════════════════════ */
(function (arrel) {
'use strict';

/* ── 1. CONFIGURACIÓ ───────────────────────────────────────────────── */

/** Durades de l'animació de les tecles, en mil·lisegons, a velocitat «ràpida». */
const TEMPS = Object.freeze({
  cursor: 430,         // el cursor va fins a una tecla
  clic: 150,           // la tecla està premuda
  entreTecles: 170,    // pausa entre dues tecles del mateix pas
  abansPantalla: 140,  // després de l'última tecla, abans que canviï la pantalla
  pantalla: 220,       // la pantalla nova apareix
});
/** Pauses de lectura quan es reprodueix tot seguit (no depenen de la velocitat de les tecles). */
const LECTURA = Object.freeze({inici: 450, pas: 1000, perParaula: 110});
/** Velocitats de les tecles: «normal» és un 50 % més lenta que «ràpida» (David, 31/10/2026). */
const VELOCITATS = Object.freeze([['normal', 1.5], ['ràpida', 1]]);
const CORBA = 'cubic-bezier(.45,.05,.25,1)';

const PEU = '© 2026 <strong>David Arso Civil</strong>. Ús educatiu lliure. Prohibida la comercialització '
  + 'i la modificació (<a rel="license" href="https://creativecommons.org/licenses/by-nc-nd/4.0/">CC BY-NC-ND 4.0</a>). '
  + 'Web no oficial, sense relació amb el fabricant de la calculadora.';


/* ── 2. UTILITATS ──────────────────────────────────────────────────── */

function element(etiqueta, atributs = {}, fills = []) {
  const e = document.createElement(etiqueta);
  for (const [k, v] of Object.entries(atributs)) {
    if (v === undefined || v === null || v === false) continue;
    if (k === 'class') e.className = v;
    else if (k === 'text') e.textContent = v;
    else if (k === 'html') e.innerHTML = v;
    else e.setAttribute(k, v === true ? '' : v);
  }
  e.append(...[].concat(fills).filter(Boolean));
  return e;
}

const espera = ms => new Promise(resol => setTimeout(resol, ms));
const escapa = s => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
const formula = t => katex.renderToString(t, {throwOnError: false});

/** Text d'una fitxa → HTML: $TeX$ = fórmula, [[id]] = tecla petita, {{Opció}} = text d'un menú. */
function text(t) {
  return String(t || '').split(/(\$[^$]+\$|\[\[[^\]]+\]\]|\{\{[^}]+\}\})/).map(tros => {
    if (/^\$[^$]+\$$/.test(tros)) return formula(tros.slice(1, -1));
    if (/^\[\[[^\]]+\]\]$/.test(tros)) return Tecles.html(tros.slice(2, -2), {petita: true});
    if (/^\{\{[^}]+\}\}$/.test(tros)) return `<span class="opcio-menu">${escapa(tros.slice(2, -2))}</span>`;
    return escapa(tros).replace(/\n/g, '<br>');
  }).join('');
}
/** Text pla (per al lector de pantalla). */
const textPla = t => String(t || '').replace(/\$([^$]+)\$/g, '$1').replace(/\[\[([^\]]+)\]\]/g, (_, id) =>
  (Tecles.TECLES[id] ? Tecles.TECLES[id].nom : id)).replace(/\{\{([^}]+)\}\}/g, '«$1»');
const paraules = t => String(t || '').replace(/\$[^$]*\$/g, ' x ').split(/\s+/).filter(Boolean).length;

function anima(el, fotogrames, opcions) {
  return el.animate(fotogrames, Object.assign({fill: 'forwards', easing: CORBA}, opcions)).finished;
}

function rectangle(el, origen) {
  const o = origen.getBoundingClientRect(), r = el.getBoundingClientRect();
  return {x: r.left - o.left, y: r.top - o.top, w: r.width, h: r.height,
    cx: r.left - o.left + r.width / 2, cy: r.top - o.top + r.height / 2};
}

function parametre(nom) {
  try { return new URLSearchParams(location.search).get(nom); } catch (e) { return null; }
}


/* ── 3. LA CALCULADORA ─────────────────────────────────────────────── */

/**
 * La calculadora sencera a partir de Tecles.TECLAT: totes les mesures en cqw
 * (percentatge de l'amplada), de manera que les tecles són cercles perfectes.
 * Cada tecla porta data-tecla="<id>" (el cursor la busca així).
 */
function htmlCalculadora() {
  const T = Tecles.TECLAT;
  const caixa = (classe, q) => `<div class="${classe}" style="left:${q.x}cqw;top:${q.y}cqw;width:${q.w}cqw;height:${q.h}cqw"></div>`;
  const tecla = id => Tecles.html(id, {teclat: true, atributs: `data-tecla="${id}"`});
  let html = caixa('marc', T.marc);
  html += T.creu.map(q => caixa('creu', q)).join('');
  html += `<div class="pagina" style="left:${T.pagina.x}cqw;top:${T.pagina.y}cqw;width:${T.pagina.w}cqw;height:${T.pagina.h}cqw">`
    + T.aLaPagina.map(tecla).join('') + '</div>';
  for (const [id, [x, y, d]] of Object.entries(T.tecles)) {
    html += `<div class="cel" style="left:${x}cqw;top:${y}cqw;--d:${d}cqw">${tecla(id)}</div>`;
  }
  return html;
}


/* ── 4. ESTRUCTURA DE LA PÀGINA ────────────────────────────────────── */

const ICONES = Object.freeze({
  reinicia: 'M12 5V2L7 6l5 4V7a5 5 0 1 1-5 5H5a7 7 0 1 0 7-7z',
  anterior: 'M15.5 5 8.5 12l7 7z',
  reprodueix: 'M8 5v14l11-7z',
  atura: 'M7 5h4v14H7zM13 5h4v14h-4z',
  seguent: 'M8.5 5l7 7-7 7z',
});
const icona = d => `<svg viewBox="0 0 24 24" aria-hidden="true"><path d="${d}"/></svg>`;
const CURSOR = '<svg viewBox="0 0 22 30" aria-hidden="true"><path d="M2 2 L2 24 L7.6 18.8 L11.4 27.4 L15 25.8 L11.3 17.4 L18.6 17.4 Z" '
  + 'fill="#fff" stroke="#111" stroke-width="1.6" stroke-linejoin="round"/></svg>';

function construeixPagina(fitxa, bloc, germanes, contenidor) {
  const boto = (classe, nom, d) => element('button', {class: 'boto ' + classe, type: 'button', title: nom, 'aria-label': nom, html: icona(d)});
  const T = Tecles.TECLAT;
  const r = {
    lcd: element('div', {class: 'lcd-pantalla', role: 'img', 'aria-label': 'Pantalla de la calculadora'}),
    passos: element('ol', {class: 'passos', 'aria-label': 'Passos'}),
    anunci: element('p', {class: 'nomes-lectors', 'aria-live': 'polite'}),
    efectes: element('div', {class: 'efectes', 'aria-hidden': 'true'}),
    cursor: element('div', {class: 'cursor', 'aria-hidden': 'true', html: CURSOR}),
    reinicia: boto('', 'Torna a començar', ICONES.reinicia),
    anterior: boto('', 'Pas anterior', ICONES.anterior),
    reprodueix: boto('principal', 'Reprodueix', ICONES.reprodueix),
    seguent: boto('', 'Pas següent', ICONES.seguent),
    velocitat: element('select', {id: 'velocitat'}),
  };
  for (const [nom, factor] of VELOCITATS) r.velocitat.append(element('option', {value: String(factor), text: nom}));

  r.calculadora = element('div', {class: 'calculadora', style: `aspect-ratio:100/${T.alcada}`, html: htmlCalculadora()});
  r.calculadora.append(element('div', {class: 'lcd', style: `left:${T.vidre.x}cqw;top:${T.vidre.y}cqw;width:${T.vidre.w}cqw;height:${T.vidre.h}cqw`}, [r.lcd]));
  r.teclat = r.calculadora;
  r.escenari = element('div', {class: 'escenari'}, [r.calculadora, r.efectes, r.cursor]);

  const enllac = f => element('a', {class: 'pastilla' + (f.id === fitxa.id ? ' actual' : ''), href: 'fitxa.html?id=' + encodeURIComponent(f.id),
    'aria-current': f.id === fitxa.id ? 'page' : null, text: f.titol});
  // Les relacionades d'un altre bloc (les del mateix bloc ja hi són)
  const relacionades = (fitxa.relacionades || []).map(id => Dades.FITXES.find(f => f.id === id)).filter(f => f && f.bloc !== fitxa.bloc);
  const altres = element('details', {class: 'altres'}, [
    element('summary', {text: 'Fitxes de «' + bloc.titol + '»'}),
    element('div', {class: 'pastilles'}, germanes.map(enllac)),
    relacionades.length ? element('p', {class: 'titol-altres', text: 'Et pot interessar'}) : null,
    relacionades.length ? element('div', {class: 'pastilles'}, relacionades.map(enllac)) : null,
  ]);

  contenidor.replaceChildren(
    element('header', {class: 'capcalera'}, [element('a', {class: 'torna', href: 'index.html#' + bloc.id, text: '← Calculadora'})]),
    element('main', {class: 'contingut'}, [
      element('div', {class: 'columna'}, [
        element('h1', {class: 'nomes-lectors', text: fitxa.titol}),
        element('p', {class: 'enunciat', html: text(fitxa.enunciat)}),
        element('div', {class: 'reproductor'}, [
          element('div', {class: 'botons'}, [r.reinicia, r.anterior, r.reprodueix, r.seguent]),
          element('label', {class: 'velocitat', for: 'velocitat', text: 'Velocitat '}, [r.velocitat]),
        ]),
        r.passos,
        r.anunci,
        altres,
      ]),
      r.escenari,
    ]),
    element('footer', {class: 'peu', html: PEU}),
  );
  return r;
}


/* ── 5. LA LLISTA DE PASSOS I LES MARQUES DEL TECLAT ──────────────── */

/**
 * Un element per pas (i un d'inicial, el pas 0): el número i les tecles; el
 * pas actual es desplega i mostra la frase. Clicar-hi hi porta.
 */
function omplPassos(r, passos, enClicar) {
  const zero = element('li', {class: 'pas zero'}, [element('div', {class: 'frase', html:
    'Prem ' + icona(ICONES.reprodueix).replace('<svg', '<svg class="icona-inline"') + ' o la fletxa ↓ del teclat per començar.'})]);
  const files = passos.map((pas, i) => {
    const tecles = pas.tecles.length
      ? pas.tecles.map((id, j) => Tecles.html(id, {ambShift: j > 0 && pas.tecles[j - 1] === 'shift'})).join('')
      : '<span class="nomes-mira">mira la pantalla</span>';
    const boto = element('button', {class: 'cap', type: 'button', title: `Ves al pas ${i + 1}`},
      [element('span', {class: 'num', text: String(i + 1)}), element('span', {class: 'tecles', html: tecles})]);
    boto.addEventListener('click', () => enClicar(i));
    return element('li', {class: 'pas'}, [boto, element('div', {class: 'frase', html: text(pas.text)})]);
  });
  r.passos.replaceChildren(zero, ...files);
  return {zero, files};
}

function marcaPassos(llista, pas) {
  llista.zero.classList.toggle('actual', pas < 0);
  llista.files.forEach((li, i) => {
    li.classList.toggle('fet', i < pas);
    li.classList.toggle('actual', i === pas);
    li.querySelector('.cap').setAttribute('aria-current', i === pas ? 'step' : 'false');
  });
  const actual = pas < 0 ? llista.zero : llista.files[pas];
  // Que el pas actual es vegi sencer dins de la llista (només es desplaça la llista, no la pàgina)
  const caixa = actual.parentElement, a = actual.offsetTop - caixa.offsetTop, b = a + actual.offsetHeight;
  if (a < caixa.scrollTop) caixa.scrollTop = a - 6;
  else if (b > caixa.scrollTop + caixa.clientHeight) caixa.scrollTop = b - caixa.clientHeight + 6;
}

/**
 * Al teclat, emmarca les tecles del pas; si n'hi ha més d'una, hi posa l'ordre
 * en què es premen (una tecla que es prem dues vegades porta «2·3»). pas < 0: cap.
 */
function marcaTeclat(r, passos, pas) {
  r.teclat.querySelectorAll('.del-pas').forEach(t => { t.classList.remove('del-pas'); t.removeAttribute('data-ordre'); });
  if (pas < 0) return;
  const tecles = passos[pas].tecles;
  const ordre = new Map();
  tecles.forEach((id, j) => ordre.set(id, (ordre.get(id) || []).concat(j + 1)));
  for (const [id, ns] of ordre) {
    const t = r.teclat.querySelector(`[data-tecla="${id}"]`);
    if (!t) continue;
    t.classList.add('del-pas');
    if (tecles.length > 1) t.setAttribute('data-ordre', ns.join('·'));
  }
}


/* ── 6. CURSOR ─────────────────────────────────────────────────────── */

function creaCursor(r, temps) {
  let x = null, y = null;
  const transforma = (escala = 1) => `translate(${x}px, ${y}px) scale(${escala})`;
  const el = r.cursor;
  return {
    async va(nx, ny) {
      if (x === null) {                       // apareix per sota de la calculadora, a la dreta
        x = r.calculadora.offsetLeft + r.calculadora.offsetWidth - 20;
        y = r.calculadora.offsetTop + r.calculadora.offsetHeight + 10;
        el.style.transform = transforma();
        el.classList.add('visible');
      }
      const sortida = transforma();
      x = nx; y = ny;
      await anima(el, [{transform: sortida}, {transform: transforma()}], {duration: temps(TEMPS.cursor)});
      el.style.transform = transforma();
      el.getAnimations().forEach(a => a.cancel());
    },
    prem(premut) {
      const [de, a] = premut ? [1, 0.84] : [0.84, 1];
      el.animate([{transform: transforma(de)}, {transform: transforma(a)}], {duration: temps(90), fill: 'forwards'});
    },
    ona(px, py) {
      const o = element('div', {class: 'ona'});
      o.style.left = px + 'px';
      o.style.top = py + 'px';
      r.efectes.append(o);
      o.animate([{transform: 'scale(.3)', opacity: 0.9}, {transform: 'scale(1.6)', opacity: 0}],
        {duration: temps(420), easing: 'ease-out'}).finished.then(() => o.remove());
    },
    amaga() {
      x = y = null;
      el.classList.remove('visible');
      el.getAnimations().forEach(a => a.cancel());
    },
  };
}


/* ── 7. REPRODUCTOR ────────────────────────────────────────────────── */

function creaReproductor(r, fitxa, temps) {
  const passos = fitxa.passos;
  const darrer = passos.length - 1;
  const cursor = creaCursor(r, temps);
  let idx = -1;                 // -1 = pas 0 (abans de començar)
  let ocupat = false, reproduint = false, torn = 0;
  let pantallaActual = null;

  function mostraPantalla(estat, canvi = false) {
    pantallaActual = estat;
    r.lcd.innerHTML = Pantalla.html(estat);
    if (canvi) r.lcd.animate([{opacity: 0.35}, {opacity: 1}], {duration: temps(TEMPS.pantalla), easing: 'ease-out'});
  }

  const llista = omplPassos(r, passos, i => salta(i));

  function pinta() {
    marcaPassos(llista, idx);
    r.anunci.textContent = idx < 0 ? textPla(fitxa.enunciat) : `Pas ${idx + 1} de ${passos.length}. ${textPla(passos[idx].text)}`;
    r.anterior.disabled = idx < 0;
    r.seguent.disabled = idx === darrer;
  }

  function marcaReproduccio(estat) {
    reproduint = estat;
    const nom = estat ? 'Atura' : 'Reprodueix';
    r.reprodueix.innerHTML = icona(estat ? ICONES.atura : ICONES.reprodueix);
    r.reprodueix.title = nom;
    r.reprodueix.setAttribute('aria-label', nom);
  }

  /** Va al pas i (-1 = pas 0), sense animació. */
  function salta(i) {
    if (ocupat) return;
    torn++;
    marcaReproduccio(false);
    idx = Math.max(-1, Math.min(darrer, i));
    mostraPantalla(idx < 0 ? fitxa.inici : passos[idx].pantalla);
    marcaTeclat(r, passos, idx);
    r.teclat.classList.remove('shift-actiu');
    cursor.amaga();
    pinta();
  }

  /** Anima el pas següent: el cursor prem les tecles del teclat i canvia la pantalla. */
  async function seguent() {
    if (ocupat || idx >= darrer) return;
    ocupat = true;
    try {
      idx++;
      pinta();
      const pas = passos[idx];
      marcaTeclat(r, passos, idx);
      const petites = [...llista.files[idx].querySelectorAll('.tecles .tecla')];
      if (pas.tecles.length) {
        for (let j = 0; j < pas.tecles.length; j++) {
          const id = pas.tecles[j];
          const t = r.teclat.querySelector(`[data-tecla="${id}"]`);
          const q = rectangle(t, r.escenari);
          await cursor.va(q.cx - 2, q.cy - 2);
          cursor.prem(true);
          t.classList.add('premuda');
          if (petites[j]) petites[j].classList.add('premuda');
          cursor.ona(q.cx, q.cy);
          await espera(temps(TEMPS.clic));
          cursor.prem(false);
          t.classList.remove('premuda');
          if (petites[j]) petites[j].classList.remove('premuda');
          // SHIFT: surt la S a la pantalla i les funcions blaves es ressalten fins a la tecla següent
          r.teclat.classList.toggle('shift-actiu', id === 'shift');
          if (id === 'shift') mostraPantalla(Pantalla.ambIndicador(pantallaActual, 'shift'));
          if (j < pas.tecles.length - 1) await espera(temps(TEMPS.entreTecles));
        }
        await espera(temps(TEMPS.abansPantalla));
      } else {
        cursor.amaga();
      }
      mostraPantalla(pas.pantalla, true);
    } finally {
      ocupat = false;
    }
    if (idx === darrer) cursor.amaga();
  }

  async function reprodueix() {
    if (reproduint) { marcaReproduccio(false); return; }
    if (ocupat) return;
    if (idx >= darrer) salta(-1);
    marcaReproduccio(true);
    const meu = ++torn;
    await espera(LECTURA.inici);
    while (reproduint && meu === torn && idx < darrer) {
      await seguent();
      if (!reproduint || meu !== torn) break;
      await espera(LECTURA.pas + paraules(passos[idx].text) * LECTURA.perParaula);
    }
    if (meu === torn) marcaReproduccio(false);
  }

  const atura = () => { if (reproduint) marcaReproduccio(false); };

  r.reprodueix.addEventListener('click', reprodueix);
  r.seguent.addEventListener('click', () => { atura(); seguent(); });
  r.anterior.addEventListener('click', () => salta(idx - 1));
  r.reinicia.addEventListener('click', () => salta(-1));

  salta(-1);
  return {salta, seguent, reprodueix, atura,
    anterior: () => salta(idx - 1),
    get pas() { return idx; }, get total() { return passos.length; }, get ocupat() { return ocupat; }};
}


/* ── 8. INICI ──────────────────────────────────────────────────────── */

function inicia(id = parametre('id'), contenidor = document.getElementById('fitxa')) {
  if (typeof katex === 'undefined') {
    contenidor.replaceChildren(element('p', {class: 'error-carrega',
      text: 'No s\'ha pogut carregar KaTeX, la biblioteca que dibuixa les fórmules. Comprova la connexió i torna a carregar la pàgina.'}));
    return null;
  }
  const fitxa = Dades.FITXES.find(f => f.id === id) || null;
  if (!fitxa) {
    contenidor.replaceChildren(element('p', {class: 'error-carrega', html:
      `No hi ha cap fitxa «${escapa(id || '')}». <a href="index.html">Torna a la portada</a>.`}));
    return null;
  }
  const bloc = Dades.BLOCS.find(b => b.id === fitxa.bloc);
  const germanes = Dades.FITXES.filter(f => f.bloc === fitxa.bloc);
  document.title = fitxa.titol + ' — Calculadora fx-82SP CW';
  document.body.style.setProperty('--cat', bloc.color);

  const r = construeixPagina(fitxa, bloc, germanes, contenidor);
  let factor = VELOCITATS[0][1];               // «normal», per defecte
  const reduit = matchMedia('(prefers-reduced-motion: reduce)').matches;
  const temps = ms => Math.max(40, ms * factor * (reduit ? 0.35 : 1));
  r.velocitat.addEventListener('change', () => { factor = parseFloat(r.velocitat.value) || VELOCITATS[0][1]; });

  const reproductor = creaReproductor(r, fitxa, temps);

  /* Teclat: espai = reprodueix o atura; ↓ o → = pas següent; ↑ o ← = pas anterior. */
  document.addEventListener('keydown', e => {
    if (e.altKey || e.ctrlKey || e.metaKey || e.defaultPrevented) return;
    const t = e.target instanceof Element ? e.target : document.body;
    if (t.closest('input, select, textarea')) return;
    if (e.key === ' ') {
      if (t.closest('button, a, summary')) return;
      e.preventDefault();
      reproductor.reprodueix();
    } else if (e.key === 'ArrowRight' || e.key === 'ArrowDown') {
      e.preventDefault();
      reproductor.atura();
      reproductor.seguent();
    } else if (e.key === 'ArrowLeft' || e.key === 'ArrowUp') {
      e.preventDefault();
      reproductor.anterior();
    }
  });
  return reproductor;
}

arrel.Motor = Object.freeze({inicia, text});

})(globalThis);
